# Group B F0 交付说明

本次完成 F0 代码和文档，F1 尚未实现。小组成员、学号和联系方式按要求留空。

## 文件

- `documents/GroupB_F0_Report.pdf`：10 页英文报告。
- `documents/GroupB_F0_Presentation.pdf`：9 页英文展示稿。
- `documents/GroupB_F0_Presentation.pptx`：可编辑展示稿，可填写第一页成员信息。
- `documents/GroupB_F0_Report_Source.md`：报告文字源稿。
- `plugin/course-ta-0.1.1.zip`：修复 PDF 无法选中的 IDEA 插件安装包，适配 2026.1.x。
- `documents/F0_0.1.1_Changes.md`：本次修复说明；原 PDF 报告和展示稿保留 0.1.0 阶段内容。
- `evidence/`：课件全量审计和自动化测试记录。
- 完整交付 ZIP 中的 `source/`：项目源码、Gradle Wrapper、五份课程课件和构建脚本。

## 使用

1. 在 IntelliJ IDEA 2026.1.x 中打开 Settings → Plugins → 齿轮 → Install Plugin from Disk，选择插件 ZIP，按提示重启。
2. 打开一个本地 Java 项目，在 View → Tool Windows → Course TA 打开侧栏。
3. 点击 Import / Rebuild，可以直接选择一个 PDF、TXT、Markdown 文件，也可以选择源码中的 `course-materials` 文件夹。每次成功导入会用当前选择的资料重建并替换知识库；要同时使用五份课件，请选择整个文件夹。
4. 导入整个课件文件夹或其中的 `2.pdf` 后，输入 `What is polymorphism?`，点击 Preview retrieval；应显示 `2.pdf | p. 22` 的课程片段。
5. 点击 Settings，填写服务商的完整 Chat Completions 地址、模型和 API Key，再点 Ask TA 生成回答。默认地址为 DeepSeek；模型名请按服务商账户实际可用模型填写。
6. 选中 Java 代码后，右键 Ask Course TA About Selected Code，填写问题、检查侧栏附加的代码，再点击 Ask TA。

源码构建：在源码目录运行 `.\tools\build.ps1 -Task Build`；复现课件审计运行 `.\tools\build.ps1 -Task Audit`。需要 JDK 21 或更高版本。首次构建需联网下载依赖。

## 已验证与待验证

0.1.1 已通过 21 项自动化测试并成功构建，包括新增的单 PDF 导入、文件名和页码保留、单 Markdown 导入及不支持格式提示测试。全量课件审计记录见 evidence/course-audit.json。旧版 0.1.0 曾被 IDEA 沙盒日志识别；本次未重新进行沙盒启动与界面点击验证。

HTTP 测试使用本地模拟服务，并未调用真实 LLM。电脑操作工具连接失败，完整 IDEA 点击流程也未验证。展示前请配置真实服务并按报告的演示流程检查。报告中的 UI 示例来自实际 Swing 组件的离屏渲染，不是真实 LLM 答复截图。

本包是 F0 阶段交付。Group B 最终提交前还需要完成 F1 的三项智能操作，补齐成员信息和真实分工，并更新报告与展示稿。
