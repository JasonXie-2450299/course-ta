# Course TA for CST3492

IntelliJ IDEA teaching assistant for Assignment A, Group B. This release implements **F0**. F1 is the next milestone and is not implemented here.

## Features

- Import a single PDF, UTF-8 TXT or Markdown file, or an entire course folder; PDF chunks retain their physical page numbers.
- Local BM25 retrieval, persisted index and four-excerpt prompt budget.
- Configurable Chat Completions endpoint, model and API key stored in IDEA PasswordSafe.
- Course answers with source IDs, document names and page/line scope; explicit general-knowledge notice when no course evidence is used.
- Course TA tool window and editor right-click action for selected-code questions.
- Offline retrieval preview, cancellation, import warnings and HTTP error handling.

## Build and run

Use **JDK 21 or later** and **IntelliJ IDEA 2026.1.x**. Java sources target Java 21. The Gradle wrapper is included. First build requires network access to Maven and JetBrains repositories.

On this Windows machine:

```powershell
.\tools\build.ps1 -Task Build
.\tools\build.ps1 -Task Audit
.\tools\build.ps1 -Task Run
```

The helper reuses the installed IDEA 2026.1.1 SDK and works around a Windows temporary-socket-path issue only for the child build. To use another installed 2026.1 IDE, pass `-IdePath 'C:\path\to\IntelliJ IDEA'`.

Portable Gradle commands (without a local SDK, Gradle downloads IDEA 2026.1.1):

```sh
./gradlew :core:test buildPlugin
./gradlew :core:auditCourse -PcourseDir=course-materials
./gradlew runIde
```

Install `build/distributions/course-ta-0.1.1.zip` via **Settings > Plugins > gear > Install Plugin from Disk**, then restart when prompted. Open a local project and choose **View > Tool Windows > Course TA**. Compatibility is deliberately limited to IDEA build `261.*`, the target used for this release.

## Use the assistant

1. Click **Import / Rebuild** and select a PDF, TXT or Markdown file, or the included `course-materials` folder. Selecting a folder imports supported files recursively; selecting a file imports only that file. Each successful import replaces the previous course index. For all five lectures, select `course-materials`. Keep assignment instructions and exam files outside this folder.
2. Click **Preview retrieval** after typing a question to inspect actual excerpts without sending data to a provider. This is a diagnostic mode, not an LLM answer.
3. Open **Settings** in the tool window. Enter the full endpoint ending in `/chat/completions`, a model supported by your provider, and an API key. The initial endpoint is `https://api.deepseek.com/chat/completions`; change the endpoint/model together for another provider. Local compatible servers may use HTTP on localhost.
4. Click **Ask TA**. This sends the question, attached selection and up to four retrieved excerpts to the chosen provider. The rest of the project is not transmitted.
5. For code questions, select code in the editor, right-click **Ask Course TA About Selected Code**, enter your question, then review the attachment and click **Ask TA**. The action does not modify code.
6. Use **Clear code** to remove an attachment, **Cancel** to stop the current request and **Clear chat** to remove visible conversation. Each request is independent; previous turns are not sent automatically.

Try `What is polymorphism?`, `How do checked exceptions work?`, `What is retrieval augmented generation?`, or `什么是多态`. An unrelated query such as `astronomy galaxy telescope` exercises the no-evidence branch.

## Project layout

| Path | Purpose |
|---|---|
| `core/src/main/java` | Ingestion, chunking, BM25, persistence, prompts, HTTP and citation checks |
| `src/main/java` | IDEA services, Swing tool window, settings and editor action |
| `src/main/resources/META-INF/plugin.xml` | Plugin registration |
| `core/src/test/java` | Automated tests and full-corpus audit |
| `course-materials` | Original lecture PDFs used for validation |
| `samples/Demo.java` | Selected-code demo |
| `tools` | Build and document generation helpers |
| `output` | Report and delivery package |

The index is stored under the opened project's `.idea/course-ta/index.json`. Rebuild after adding, changing or deleting materials. Normal settings are in project workspace state; credentials are in PasswordSafe. Conversation is in memory only. Exclude `.idea` and API keys from submissions.

## Limits and validation

PDF parsing supports extractable text, not OCR. PDF page numbers are physical 1-based page positions, which may differ from printed slide labels. TXT/Markdown citations use inclusive line ranges. Corrupt files and empty PDF pages produce visible warnings. Input file size is capped at 50 MiB.

BM25 is lexical retrieval, with simple plural normalization, camel-case splitting and a small Chinese topic alias dictionary. It is not a multilingual embedding model; paraphrases can miss relevant slides. Citation validation verifies source IDs and refuses missing/invalid references, but does not prove that every generated claim follows from the cited excerpt. Review answers against the displayed evidence.

Unit and local HTTP contract tests do not establish the quality of a live provider. A real model/API key must be configured for the final live demonstration. The report records the checks actually completed.

## Group B completion

The final Group B assignment also requires F1: scenario-based JUnit generation, staged-diff commit-message generation, and one creative action. Complete those features and update the report/slides before the final submission. Fill in team names, matriculation numbers and contact details.

## References

- [IntelliJ Platform Gradle Plugin](https://plugins.jetbrains.com/docs/intellij/tools-intellij-platform-gradle-plugin.html)
- [Tool windows](https://plugins.jetbrains.com/docs/intellij/tool-windows.html)
- [PasswordSafe](https://plugins.jetbrains.com/docs/intellij/persisting-sensitive-data.html)
- [PDFBox 3 migration guide](https://pdfbox.apache.org/3.0/migration.html)
- [DeepSeek Chat Completions](https://api-docs.deepseek.com/api/create-chat-completion/)

Lecture content remains attributed to Dr. Fan Hongfei and is supplied here for this coursework.
